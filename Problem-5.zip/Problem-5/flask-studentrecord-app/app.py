from flask import Flask,render_template,g,request,flash,redirect,url_for,session,flash
import os
from functools import wraps
#import sqlite3
import os
app = Flask(__name__)

app.secret_key = os.urandom(24)

@app.route('/')
def welcome():
 return render_template('welcome.html')

@app.route('/home')
def home():
 return render_template('home.html')

@app.route('/sef')
def sef():
 return render_template('search.html')

@app.route('/sef1')
def sef1():
 return render_template('search1.html')

@app.route('/del')
def delt():
 return render_template('del.html')

@app.route('/stud', methods=['GET','POST'])
def stud():
 return render_template('stud.html')

students = []

@app.route('/rec')
def rec():
 row = students
 return render_template('index.html',row=row)

@app.route('/rec1')
def rec1():
 row = students
 return render_template('index1.html',row=row)

@app.route('/ser',methods=['POST'])
def ser():
 row = []
 for student in students:
    if request.form['search'] in student:
        row.append(student)
 return render_template("index.html",row=row)

@app.route('/ser1',methods=['POST'])
def ser1():
    row = {}
    for student in students:
        if request.form['search'] in student:
            row.append(student)
    return render_template("index1.html",row=row)

@app.route('/delete',methods=['POST'])
def delete():
    indexes = []
    i = 0
    for student in students:
        if request.form['delete'] in student:
            indexes.append(i)
        i += 1
    for index in indexes:
        students.pop(index)
    row=students
    return render_template("delete.html",row=row)

@app.route('/add', methods=['POST'])
def add():
 record = [request.form['rno'], request.form['name'], request.form['age'], request.form['gender']]
 students.append(record)
 flash('posted')
 return redirect(url_for('home'))

@app.route('/search')
def search():
 return render_template("search.html")

if __name__ == '__main__':
 app.run(debug=True)
